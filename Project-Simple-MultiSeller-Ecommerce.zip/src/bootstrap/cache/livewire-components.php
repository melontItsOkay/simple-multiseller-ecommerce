<?php return array (
  'base-component' => 'App\\Http\\Livewire\\BaseComponent',
  'cart-component' => 'App\\Http\\Livewire\\CartComponent',
  'checkout-component' => 'App\\Http\\Livewire\\CheckoutComponent',
  'detail-product-component' => 'App\\Http\\Livewire\\DetailProductComponent',
  'thanksyou-component' => 'App\\Http\\Livewire\\ThanksyouComponent',
  'track-order-component' => 'App\\Http\\Livewire\\TrackOrderComponent',
);