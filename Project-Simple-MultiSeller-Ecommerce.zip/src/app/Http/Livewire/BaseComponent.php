<?php

namespace App\Http\Livewire;

use App\Models\Product;
use Livewire\Component;
use Cart;

class BaseComponent extends Component
{
    public function store($product_id, $product_name, $product_price)
    {
        Cart::add($product_id, $product_name, 1, $product_price)->associate('App\Models\Product');
        session()->flash('message', 'Your Item added in cart.');
        return redirect()->route('cart');
    }

    public function render()
    {
        $product = Product::get();
        return view('livewire.base-component', ['product' => $product])->layout('layout.base');
    }
}
