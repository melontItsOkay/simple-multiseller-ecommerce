<?php

namespace App\Http\Livewire;

use Livewire\Component;

class TrackOrderComponent extends Component
{
    public function trackorder($orderId)
    {
        
    }

    public function render()
    {
        return view('livewire.track-order-component')->layout('layout.base');
    }
}
