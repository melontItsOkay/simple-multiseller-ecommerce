<?php

namespace App\Http\Livewire\Guest;

use Livewire\Component;

class ThanksyouComponent extends Component
{
    public function render()
    {
            return view('livewire.guest.thanksyou-component')->layout('layout.base');
    }
}
