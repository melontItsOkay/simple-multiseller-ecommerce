<?php

namespace App\Http\Livewire\Guest;

use Cart;
use App\Models\Order;
use App\Models\Product;
use Livewire\Component;
use App\Models\Shipping;
use App\Models\Transaction;
use Illuminate\Support\Str;
use App\Models\OrderProduct;

class CheckoutComponent extends Component
{
    public $shipping_to_diffrent;

    public $firstname;
    public $lastname;
    public $line1;
    public $line2;
    public $city;
    public $state;
    public $country;
    public $mobile;

    public $s_firstname;
    public $s_lastname;
    public $s_line1;
    public $s_line2;
    public $s_city;
    public $s_state;
    public $s_country;
    public $s_mobile;

    public $paymentmethod;

    public function updated($fields)
    {

        $this->validateOnly($fields,[
            'firstname' => 'required',
            'lastname' => 'required',
            'line1' => 'required',
            'city' => 'required',
            'state' => 'required',
            'country' => 'required',
            'mobile' => 'required|numeric',
            'paymentmethod' => 'required'
        ]);

        if($this->shipping_to_diffrent)
        {
            $this->validateOnly($fields,[
                's_firstname' => 'required',
                's_lastname' => 'required',
                's_line1' => 'required',
                's_city' => 'required',
                's_state' => 'required',
                's_country' => 'required',
                's_mobile' => 'required|numeric',
                'paymentmethod' => 'required'
            ]);
        }

    }

    public function placeorder()
    {
        $this->validate([
            'firstname' => 'required',
            'lastname' => 'required',
            'line1' => 'required',
            'city' => 'required',
            'state' => 'required',
            'country' => 'required',
            'mobile' => 'required|numeric',
            'paymentmethod' => 'required'
        ]);

        $createdorderid = Str::random(20);
        $order = new Order();
        $order->order_id = $createdorderid;
        $order->sub_total = Cart::subtotal();
        $order->discount = '0';
        $order->tax = Cart::tax();
        $order->total = Cart::total();
        $order->fistname = $this->firstname; 
        $order->lastname = $this->lastname; 
        $order->line1 = $this->line1;
        $order->line2 = $this->line2;
        $order->city = $this->city;
        $order->state = $this->state;
        $order->country = $this->country;
        $order->mobile = $this->mobile;
        $order->status = 'Pending';
        $order->is_shipping_diffrent = $this->shipping_to_diffrent ? 1:0;
        $order->save();


        foreach (Cart::content() as $item) 
        {
            $orderItem = new OrderProduct();
            $orderItem->product_name = $item->name;
            $orderItem->order_id = $order->id;
            $orderItem->price = $item->price;
            $orderItem->quantity = $item->qty;
            $orderItem->save();
            
            $product = Product::find($item->id);
            $product->id = $item->id;
            $product->total_sold = $product->total_sold + $item->qty;
            $product->save();
            
        }

        if($this->shipping_to_diffrent)
        {
            $this->validate([
                's_firstname' => 'required',
                's_lastname' => 'required',
                's_line1' => 'required',
                's_city' => 'required',
                's_state' => 'required',
                's_country' => 'required',
                's_mobile' => 'required|numeric',
                'paymentmethod' => 'required'
            ]);

            $shipping = new Shipping();
            $shipping->order_id = $order->id;
            $shipping->firstname = $this->firstname; 
            $shipping->lastname = $this->lastname; 
            $shipping->line1 = $this->line1;
            $shipping->line2 = $this->line2;
            $shipping->city = $this->city;
            $shipping->state = $this->state;
            $shipping->country = $this->country;
            $shipping->mobile = $this->mobile;
            $shipping->save();

        }

        if($this->paymentmethod == 'cod')
        {
            $transaction = new Transaction();
            $transaction->order_id = $order->id;
            $transaction->payment = 'Cash on Delivery';
            $transaction->status = 'Process';
            $transaction->save();
        }

        Cart::destroy();
        session()->flash('orderid', $createdorderid);
        return redirect()->route('thank');

    }

    public function render()
    {
        return view('livewire.guest.checkout-component')->layout('layout.base');
    }
}
