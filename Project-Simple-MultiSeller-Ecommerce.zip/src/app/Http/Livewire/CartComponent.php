<?php

namespace App\Http\Livewire;

use Cart;
use Livewire\Component;
use Illuminate\Support\Str;

class CartComponent extends Component
{

    public function IncreaseQuantity($rowId)
    {
        $product = Cart::get($rowId);
        $qty = $product->qty + 1;
        Cart::update($rowId, $qty);
    }

    public function DecreaseQuantity($rowId)
    {
        $product = Cart::get($rowId);
        $qty = $product->qty - 1;
        Cart::update($rowId, $qty);
    }

    public function DeleteById($rowId)
    {
        Cart::remove($rowId);
        return session()->flash('removed', 'Item has been removed.');
    }

    public function DeleteAll()
    {
        Cart::destroy();
        return session()->flash('removed', 'Your cart has been empty.');
    }

    public function MakeOrder()
    {
        $orderId = Str::random(20);

        return redirect()->route('checkout.before', $orderId);
    }

    public function render()
    {
        return view('livewire.cart-component')->layout('layout.base');
    }
}
