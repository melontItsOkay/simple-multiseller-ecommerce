<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Shipping extends Model
{
    use HasFactory;
    
    protected $table = 'order_shipping';
    protected $guarded = 'id';
    protected $fillable = [
        'order_id',
        'fistname',
        'lastname',
        'line1',
        'line2',
        'city',
        'state',
        'country',
        'mobile',
    ];
}
