<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;
    
    protected $table = 'checkout_order';
    protected $guarded = 'id';
    protected $fillable = [
        'order_id',
        'sub_total',
        'discount',
        'tax',
        'total',
        'fistname',
        'lastname',
        'line1',
        'line2',
        'city',
        'state',
        'country',
        'mobile',
        'status',
        'is_shipping_diffrent',
    ];
}
