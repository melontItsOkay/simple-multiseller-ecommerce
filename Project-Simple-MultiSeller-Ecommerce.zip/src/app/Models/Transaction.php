<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    use HasFactory;

    protected $table = 'checkout_transaction';
    protected $guarded = 'id';
    protected $fillable = [
        'order_id',
        'payment',
        'status'
    ];
}
