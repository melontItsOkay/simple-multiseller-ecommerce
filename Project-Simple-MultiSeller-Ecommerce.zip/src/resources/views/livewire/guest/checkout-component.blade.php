<main>

    <section class="py-3 text-center container">
        <div class="row py-lg-5">
            <div class="col-lg-6 col-md-8 mx-auto">
                <h1 class="fw-light">Checkout</h1>
                </p>
            </div>
        </div>
    </section>
 
    <div class="album py-5 bg-light">
        <div class="container">
            <form>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-text">Billing Informations</h5>
                            <hr class="dropdown-divider">
                            <div class="mb-3 mt-4 row">
                                <label class="col-sm-2 col-form-label">First Name</label>
                                <div class="col-sm-4">
                                  <input type="text" class="form-control" name="fname" wire:model="firstname">
                                  @error('firstname') <small class="text-danger">{{$message}}</small> @enderror
                                </div>
                            </div>
                            <div class="mb-3 mt-4 row">
                                <label class="col-sm-2 col-form-label">Last Name</label>
                                <div class="col-sm-4">
                                  <input type="text" class="form-control" name="lname" wire:model="lastname">
                                  @error('lastname') <small class="text-danger">{{$message}}</small> @enderror
                                </div>
                            </div>
                            <div class="mb-3 mt-4 row">
                                <label class="col-sm-2 col-form-label">Address Line 1</label>
                                <div class="col-sm-4">
                                  <input type="text" class="form-control" name="line1" wire:model="line1">
                                  @error('line1') <small class="text-danger">{{$message}}</small> @enderror
                                </div>
                            </div>
                            <div class="mb-3 mt-4 row">
                                <label class="col-sm-2 col-form-label">Address Line 2</label>
                                <div class="col-sm-4">
                                  <input type="text" class="form-control" placeholder="Optional" name="line2" wire:model="line2">
                                </div>
                            </div>
                            <div class="mb-3 mt-4 row">
                                <label class="col-sm-2 col-form-label">City</label>
                                <div class="col-sm-4">
                                  <input type="text" class="form-control" name="city" wire:model="city">
                                  @error('city') <small class="text-danger">{{$message}}</small> @enderror
                                </div>
                            </div>
                            <div class="mb-3 mt-4 row">
                                <label class="col-sm-2 col-form-label">State</label>
                                <div class="col-sm-4">
                                  <input type="text" class="form-control" name="state" wire:model="state">
                                  @error('state') <small class="text-danger">{{$message}}</small> @enderror
                                </div>
                            </div>
                            <div class="mb-3 mt-4 row">
                                <label class="col-sm-2 col-form-label">Country</label>
                                <div class="col-sm-4">
                                  <select name="country" class="form-control" wire:model="country">
                                      <option value="">choose your country</option>
                                      <option disabled>_________________________</option>
                                      <option value="United State">United State</option>
                                      <option value="United Kingdom">United Kingdom</option>
                                      <option value="Malaysia">Malaysia</option>
                                      <option value="Indonesia">Indonesia</option>
                                      <option value="Singapore">Singapore</option>
                                  </select>
                                  @error('country') <small class="text-danger">{{$message}}</small> @enderror
                                </div>
                            </div>
                            <div class="mb-3 mt-4 row">
                                <label class="col-sm-2 col-form-label">Phone Number</label>
                                <div class="col-sm-4">
                                  <input type="text" class="form-control" name="mobile" wire:model="mobile">
                                  @error('mobile') <small class="text-danger">{{$message}}</small> @enderror
                                </div>
                            </div>
                            <div class="mb-3 mt-4 row">
                                <div class="col-sm-4">
                                  <input type="checkbox" wire:model="shipping_to_diffrent" value="1" > <small>Shipping to diffrent address</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                @if($shipping_to_diffrent)
                <div class="row mt-4">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-text">Shipping Address</h5>
                                <hr class="dropdown-divider">
                                <div class="mb-3 mt-4 row">
                                    <label class="col-sm-2 col-form-label">First Name</label>
                                    <div class="col-sm-4">
                                      <input type="text" class="form-control" name="fname" wire:model="s_firstname">
                                    </div>
                                </div>
                                <div class="mb-3 mt-4 row">
                                    <label class="col-sm-2 col-form-label">Last Name</label>
                                    <div class="col-sm-4">
                                      <input type="text" class="form-control" name="lname" wire:model="s_lastname">
                                    </div>
                                </div>
                                <div class="mb-3 mt-4 row">
                                    <label class="col-sm-2 col-form-label">Address Line 1</label>
                                    <div class="col-sm-4">
                                      <input type="text" class="form-control" name="line1" wire:model="s_line1">
                                    </div>
                                </div>
                                <div class="mb-3 mt-4 row">
                                    <label class="col-sm-2 col-form-label">Address Line 2</label>
                                    <div class="col-sm-4">
                                      <input type="text" class="form-control" placeholder="Optional" name="line2" wire:model="s_line2">
                                    </div>
                                </div>
                                <div class="mb-3 mt-4 row">
                                    <label class="col-sm-2 col-form-label">City</label>
                                    <div class="col-sm-4">
                                      <input type="text" class="form-control" name="city" wire:model="s_city">
                                    </div>
                                </div>
                                <div class="mb-3 mt-4 row">
                                    <label class="col-sm-2 col-form-label">State</label>
                                    <div class="col-sm-4">
                                      <input type="text" class="form-control" name="state" wire:model="s_state">
                                    </div>
                                </div>
                                <div class="mb-3 mt-4 row">
                                    <label class="col-sm-2 col-form-label">Country</label>
                                    <div class="col-sm-4">
                                      <select name="country" class="form-control" wire:model="s_country">
                                          <option value="">choose your country</option>
                                          <option disabled>_________________________</option>
                                          <option value="United State">United State</option>
                                          <option value="United Kingdom">United Kingdom</option>
                                          <option value="Malaysia">Malaysia</option>
                                          <option value="Indonesia">Indonesia</option>
                                          <option value="Singapore">Singapore</option>
                                      </select>
                                    </div>
                                </div>
                                <div class="mb-3 mt-4 row">
                                    <label class="col-sm-2 col-form-label">Phone Number</label>
                                    <div class="col-sm-4">
                                      <input type="text" class="form-control" name="mobile" wire:model="s_mobile">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endif

            <div class="row mt-4">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-text">Payment Method</h5>
                        <hr class="dropdown-divider">
                        <div class="mb-3 mt-4 row">
                            <div class="col-sm-4">
                              <input type="checkbox" name="paymentmethod" value="cod" wire:model="paymentmethod"> <small>Cash On Delivery</small>
                            </div>
                            @error('paymentmethod') <small class="text-danger">{{$message}}</small> @enderror
                        </div>
                        <hr class="dropdown-divider">
                        <p class="card-text"><b>Grand Total: {{Cart::total()}}</b></p>
                    </div>
                </div>
            </div>
            </div>  

            <div class="mb-3 mt-4 row">
                <div class="col-sm-3">
                <button type="submit" class="btn btn-primary form-control" wire:click.prevent="placeorder">Place order now</button>
                </div>
            </div>
            </form>
        </div>
    </div>
</main>