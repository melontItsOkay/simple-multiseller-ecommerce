@if(session()->has('orderid'))
<main>

    <section class="py-3 text-center container">
        <div class="row py-lg-5">
            <div class="col-lg-6 col-md-8 mx-auto">
                <h1 class="fw-light">Thanks You</h1>
                </p>
            </div>
        </div>
    </section>
    
    <div class="album py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Thanks for order.</h2>
                    @if(session()->has('orderid'))
                    <p><b>OrderID:</b> {{session()->get('orderid')}} <p>
                    @endif
                    <p>A confirmation email was sent.</p>
                    <a href="/" class="btn btn-success">Continue Shopping</a>
                </div>
            </div>
        </div>
    </div>
    

</main>
@else 
   <meta http-equiv="refresh" content="0; url=/">
    @endif