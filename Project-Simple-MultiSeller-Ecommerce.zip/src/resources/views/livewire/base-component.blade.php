<main>
  
  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <h1 class="fw-light">Simple MultiSeller eCommerce</h1>
        <p class="lead text-muted">Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat architecto beatae voluptates rerum maxime nesciunt earum quas inventore reprehenderit unde?</p>
        <p>
          <a href="#" class="btn btn-primary my-2">Shop</a>
        </p>
      </div>
    </div>
  </section>

  <div class="album py-5 bg-light">
    <div class="container">

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">

        @forelse ($product as $item)
        <div class="col">
          <div class="card shadow-sm">
            <img src="{{asset('assets/img')}}/{{$item->img_product}}" class="bd-placeholder-img card-img-top" width="100%" height="225" alt="{{$item->name_product}}" />

            <div class="card-body">
              <div class="card-heading">
                <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
                <small class="card-text text-white col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0 badge bg-warning">Discount 20%</small>
                <div class="text-end">
                <small class="text-muted">{{$item->total_sold}} Sales</small>
                </div>
              </div>
              </div>
              <p class="card-text"><a href="" class="text-decoration-none">{{$item->name_product}}</a></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-primary" wire:click.prevent="store({{$item->id}}, '{{$item->name_product}}', {{$item->price}})"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart" viewBox="0 0 16 16">
                    <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
                  </svg></button>
                  <a href="{{route('detail.product', $item->slug)}}" class="btn btn-sm btn-outline-primary">View Details</a>
                </div>
                <small class="text-muted h5">${{$item->price}}</small>
              </div>
            </div>
          </div>
        </div>
        @empty
        <p class="text-muted">No found product records.</p>
        @endforelse
       
      </div>
    </div>
  </div>

</main>