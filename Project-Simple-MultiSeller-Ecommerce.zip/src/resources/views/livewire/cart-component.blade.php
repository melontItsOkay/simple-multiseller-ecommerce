<main>

    <section class="py-3 text-center container">
        <div class="row py-lg-5">
            <div class="col-lg-6 col-md-8 mx-auto">
                <h1 class="fw-light">Your Cart</h1>
                </p>
            </div>
        </div>
    </section>

    <div class="album py-5 bg-light">
        <div class="container">
            @if(session()->has('message'))
            <div class="alert alert-success col-md-4">
                <strong>Success!</strong> {{session()->get('message')}}
            </div>
            @endif
            @if(session()->has('removed'))
            <div class="alert alert-success col-md-4">
                <strong>Success!</strong> {{session()->get('removed')}}
            </div>
            @endif
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                <div class="card col-md-12">
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse (Cart::content() as $item)
                                <tr>
                                    <td>{{$item->name}}</td>
                                    <td><button class="btn btn-outline-secondary text-muted"
                                            wire:click.prevent="DecreaseQuantity('{{$item->rowId}}')">-</button> <button
                                            class="btn btn-outline-secondary text-muted"
                                            wire:click.prevent="IncreaseQuantity('{{$item->rowId}}')">+</button> <input
                                            type="text" class="col-sm-2 bg-white text-center"
                                            style="border-inline: white" readonly value="{{$item->qty}}"></td>
                                            <td>{{$item->total}}</td>
                                    <td><button class="btn btn-danger"
                                            wire:click.prevent="DeleteById('{{$item->rowId}}')">X</button></td>
                                </tr>
                                @empty
                                <tr>
                                    <td>No item in cart.</td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                @endforelse
                                @if(Cart::count() > 0)
                                <button class="btn btn-danger" wire:click="DeleteAll">Empty Cart</button>
                                @else
                                @endif
                            </tbody>
                        </table>
                        <p>Tax: ${{Cart::tax()}}</p>
                        <p><b>Total: ${{Cart::total()}}</b></p>
                    </div>
                </div>
                @if(Cart::count() > 0)
                <button type="button" class="btn btn-success col-lg-2" data-bs-toggle="modal"
                    data-bs-target="#checkout">
                    Checkout
                </button>
                <!-- Modal -->
                <div class="modal fade" id="checkout" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="checkout" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="checkout">Checkout Gateway</h5> 
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <button class="btn btn-primary">Sign In</button>
                                <p class="mt-3 text-muted" style="font-style: italic">Or</p>
                                <button class="btn btn-primary" wire:click.prevent="MakeOrder">Guest Checkout</button>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                {{-- <button type="button" class="btn btn-primary">Understood</button> --}}
                            </div>
                        </div>
                    </div>
                </div>
                @else
                <a href="/" class="btn btn-success col-lg-2">Shopping</a>
                @endif
            </div>

        </div>
    </div>

</main>
