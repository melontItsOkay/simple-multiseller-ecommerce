<?php

use App\Http\Livewire\BaseComponent;
use App\Http\Livewire\CartComponent;
use Illuminate\Support\Facades\Route;
use App\Http\Livewire\Guest\CheckoutComponent;
use App\Http\Livewire\Guest\ThanksyouComponent;
use App\Http\Livewire\TrackOrderComponent;
use App\Http\Livewire\DetailProductComponent;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', BaseComponent::class)->name('home');
Route::get('/cart', CartComponent::class)->name('cart');
Route::get('/detail/product/{slug}', DetailProductComponent::class)->name('detail.product');
Route::get('/checkout/{orderid}', CheckoutComponent::class)->name('checkout.before');
Route::get('/thanks', ThanksyouComponent::class)->name('thank');
Route::get('/track-order', TrackOrderComponent::class)->name('track');