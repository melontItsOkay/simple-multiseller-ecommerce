<footer class="text-muted py-5">
    <div class="container">
      <p class="float-end mb-1">
        <a href="#">Back to top</a>
      </p>
      <p class="mb-1">Simple MultiSeller &copy; <?php echo e(date('Y')); ?> All Resevered.</p>
    </div>
  </footer><?php /**PATH C:\xampp\htdocs\melont2\resources\views/layout/footer.blade.php ENDPATH**/ ?>