<main>
  
    <section class="py-5 text-center container">
      <div class="row py-lg-5">
        <div class="col-lg-6 col-md-8 mx-auto">
          <h1 class="fw-light">Detail Product</h1>
          <p class="lead text-muted">Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat architecto beatae voluptates rerum maxime nesciunt earum quas inventore reprehenderit unde?</p>
          
        </div>
      </div>
    </section>
  
    <div class="album py-5 bg-light">
      <div class="container">
  
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">

            <div class="col-md-9">
                <div class="card">
                    <div class="card-body">
                        <img src="<?php echo e(asset('assets/img')); ?>/<?php echo e($product->img_product); ?>" class="offset-md-3 bd-placeholder-img-lg" width="50%" height="325" />

                        <hr>
                        <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
                            <h6 class="card-text text-muted col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0"><?php echo e($product->name_product); ?></h6>
                            <div class="text-end">
                            <small class="badge bg-warning text-white">Discount 2%</small>
                        </div>
                        </div>

                        <ul class="nav nav-tabs mt-5" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                              <button class="nav-link active" id="Description-tab" data-bs-toggle="tab" data-bs-target="#Description" type="button" role="tab" aria-controls="home" aria-selected="true">Description</button>
                            </li>
                            <li class="nav-item" role="presentation">
                              <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Feedback</button>
                            </li>
                            <li class="nav-item" role="presentation">
                              <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Contact Seller</button>
                            </li>
                          </ul>
                          <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="Description" role="tabpanel" aria-labelledby="Description-tab"><?php echo e($product->description); ?></div>
                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">...</div>
                            <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
                          </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <p class="mb-3"><strong>Price Fixed: $<?php echo e($product->price); ?></strong></p>
                        <hr>
                        <button class="btn btn-info text-white" wire:click.prevent="store(<?php echo e($product->id); ?>, '<?php echo e($product->name_product); ?>', <?php echo e($product->price); ?>)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart-plus" viewBox="0 0 16 16">
                            <path d="M9 5.5a.5.5 0 0 0-1 0V7H6.5a.5.5 0 0 0 0 1H8v1.5a.5.5 0 0 0 1 0V8h1.5a.5.5 0 0 0 0-1H9V5.5z"/>
                            <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1H.5zm3.915 10L3.102 4h10.796l-1.313 7h-8.17zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
                          </svg> Add to cart</button>
                    </div>
                </div>
            </div>

        </div>

      </div>
    </div>

</main><?php /**PATH C:\xampp\htdocs\melont2\resources\views/livewire/detail-product-component.blade.php ENDPATH**/ ?>