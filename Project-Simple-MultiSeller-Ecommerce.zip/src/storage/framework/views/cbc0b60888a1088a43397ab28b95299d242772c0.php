<main>

    <section class="py-3 text-center container">
        <div class="row py-lg-5">
            <div class="col-lg-6 col-md-8 mx-auto">
                <h1 class="fw-light">Track Your Order</h1>
                </p>
            </div>
        </div>
    </section>

    <div class="album py-5 bg-light">
        <div class="container">
            <form>
            <div class="row g-3">
                <div class="col-md-2">
                    <label class="visually-hidden">Order ID:</label>
                    <input type="text" class="form-control" placeholder="Your order id">
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-primary mb-3">Track</button>
                </div>
            </div>
            </form>
        </div>
    </div>
    </div>

</main>
<?php /**PATH C:\xampp\htdocs\melont2\resources\views/livewire/track-order-component.blade.php ENDPATH**/ ?>