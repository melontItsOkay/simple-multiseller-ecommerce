-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 28, 2021 at 02:56 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `simple_multiseller`
--

-- --------------------------------------------------------

--
-- Table structure for table `checkout_order`
--

CREATE TABLE `checkout_order` (
  `id` int(11) NOT NULL,
  `order_id` varchar(128) NOT NULL,
  `sub_total` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `tax` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `fistname` varchar(128) NOT NULL,
  `lastname` varchar(128) NOT NULL,
  `line1` varchar(128) NOT NULL,
  `line2` varchar(128) DEFAULT NULL,
  `city` varchar(128) NOT NULL,
  `state` varchar(128) NOT NULL,
  `country` varchar(128) NOT NULL,
  `mobile` varchar(128) NOT NULL,
  `status` enum('Pending','Process','Delivery','') NOT NULL,
  `is_shipping_diffrent` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `checkout_order`
--

INSERT INTO `checkout_order` (`id`, `order_id`, `sub_total`, `discount`, `tax`, `total`, `fistname`, `lastname`, `line1`, `line2`, `city`, `state`, `country`, `mobile`, `status`, `is_shipping_diffrent`, `created_at`, `updated_at`) VALUES
(1, '0U0UurZZkQWwT8nRa5ls', 216, 0, 0, 216, 'Nikko', 'Melonnt', 'Jln. Mutiara Emas 8', NULL, 'Johor', 'Johor Bahru', 'Malaysia', '0116137237', 'Pending', 0, '2021-08-28 04:40:45', '2021-08-28 04:40:45');

-- --------------------------------------------------------

--
-- Table structure for table `checkout_product`
--

CREATE TABLE `checkout_product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(225) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `checkout_product`
--

INSERT INTO `checkout_product` (`id`, `product_name`, `order_id`, `price`, `quantity`, `created_at`, `updated_at`) VALUES
(1, 'Macbook Air Pro 6inch', 1, 54, 4, '2021-08-28 04:40:45', '2021-08-28 04:40:45');

-- --------------------------------------------------------

--
-- Table structure for table `checkout_transaction`
--

CREATE TABLE `checkout_transaction` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment` varchar(128) NOT NULL,
  `status` varchar(128) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `checkout_transaction`
--

INSERT INTO `checkout_transaction` (`id`, `order_id`, `payment`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Cash on Delivery', 'Process', '2021-08-28 04:40:45', '2021-08-28 04:40:45');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_shipping`
--

CREATE TABLE `order_shipping` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `firstname` varchar(128) NOT NULL,
  `lastname` varchar(128) NOT NULL,
  `line1` varchar(128) NOT NULL,
  `line2` varchar(128) DEFAULT NULL,
  `city` varchar(128) NOT NULL,
  `state` varchar(128) NOT NULL,
  `country` varchar(1288) NOT NULL,
  `mobile` varchar(128) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name_product` varchar(225) NOT NULL,
  `img_product` varchar(128) NOT NULL,
  `description` text NOT NULL,
  `price` int(11) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `slug` varchar(128) NOT NULL,
  `status` enum('Active','Disabled') NOT NULL,
  `total_sold` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name_product`, `img_product`, `description`, `price`, `discount`, `slug`, `status`, `total_sold`, `created_at`, `updated_at`) VALUES
(1, 'Dell Latidude', 'work1.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi laboriosam iusto autem unde ab quisquam modi quae eos soluta. Voluptatum aut in nulla. Quod animi facere atque ipsa sint debitis.', 12, 0, 'dell-latidude', 'Active', 4, NULL, '2021-08-28 04:35:00'),
(2, 'Acer Cheap Laptops', 'work2.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi laboriosam iusto autem unde ab quisquam modi quae eos soluta. Voluptatum aut in nulla. Quod animi facere atque ipsa sint debitis.', 25, 0, 'acer-cheap-laptops', 'Active', 2, NULL, '2021-08-28 04:30:50'),
(3, 'Macbook Air Pro 6inch', 'work4.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi laboriosam iusto autem unde ab quisquam modi quae eos soluta. Voluptatum aut in nulla. Quod animi facere atque ipsa sint debitis.', 54, 0, 'macbook-air-pro-16inch', 'Active', 7, NULL, '2021-08-28 04:40:45');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `checkout_order`
--
ALTER TABLE `checkout_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkout_product`
--
ALTER TABLE `checkout_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkout_transaction`
--
ALTER TABLE `checkout_transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_shipping`
--
ALTER TABLE `order_shipping`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `checkout_order`
--
ALTER TABLE `checkout_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `checkout_product`
--
ALTER TABLE `checkout_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `checkout_transaction`
--
ALTER TABLE `checkout_transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `order_shipping`
--
ALTER TABLE `order_shipping`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
